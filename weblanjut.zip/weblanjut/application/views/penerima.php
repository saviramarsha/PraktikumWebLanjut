<?php 
echo "data yang dikirimkan adalah ".$test."<br>";
echo "gaji yang dikirimkan adalah ".$test;

?>